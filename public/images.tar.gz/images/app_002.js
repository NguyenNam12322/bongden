window._subiz_init_2094850928430 = true
window._subiz_init_2094850928430_keep_loading = true
var tag = document.createElement('script')
tag.async = 1
tag.src = 'https://vcdn.subiz-cdn.com/widget-v4/public/183cf1f205f.app.js'

if (document.readyState === "interactive" || document.readyState === "complete") document.body.appendChild(tag)
else document.addEventListener("DOMContentLoaded", function(event) {
	document.body.appendChild(tag)
}) // 183cf1f205f